/*!
 * vue-admin-better
 * GitHub: https://github.com/zxwk1998/vue-admin-better
 * Gitee: https://gitee.com/chu1204505056/vue-admin-better
 *
 * 版权所有 (c) 2025 vue-admin-better
 * 本项目使用 MIT 许可证
 * 构建时间: 2026-11-8 08:24:59
 */
"use strict";
(self["rspackChunkvue_admin_better"] = self["rspackChunkvue_admin_better"] || []).push([[7373], {
4254: (function (module, __webpack_exports__, __webpack_require__) {
__webpack_require__.r(__webpack_exports__);
/* import */ var _node_modules_pnpm_css_loader_7_1_5_rspack_core_2_3_1_webpack_5_112_0_clean_css_5_3_3_cssnano_5_1_15_post_febb2288d7899141871e91de754b8b49_node_modules_css_loader_dist_runtime_noSourceMaps_js__rspack_import_1 = __webpack_require__(55489);
/* import */ var _node_modules_pnpm_css_loader_7_1_5_rspack_core_2_3_1_webpack_5_112_0_clean_css_5_3_3_cssnano_5_1_15_post_febb2288d7899141871e91de754b8b49_node_modules_css_loader_dist_runtime_noSourceMaps_js__rspack_import_1_default = /*#__PURE__*/__webpack_require__.n(_node_modules_pnpm_css_loader_7_1_5_rspack_core_2_3_1_webpack_5_112_0_clean_css_5_3_3_cssnano_5_1_15_post_febb2288d7899141871e91de754b8b49_node_modules_css_loader_dist_runtime_noSourceMaps_js__rspack_import_1);
/* import */ var _node_modules_pnpm_css_loader_7_1_5_rspack_core_2_3_1_webpack_5_112_0_clean_css_5_3_3_cssnano_5_1_15_post_febb2288d7899141871e91de754b8b49_node_modules_css_loader_dist_runtime_api_js__rspack_import_0 = __webpack_require__(78122);
/* import */ var _node_modules_pnpm_css_loader_7_1_5_rspack_core_2_3_1_webpack_5_112_0_clean_css_5_3_3_cssnano_5_1_15_post_febb2288d7899141871e91de754b8b49_node_modules_css_loader_dist_runtime_api_js__rspack_import_0_default = /*#__PURE__*/__webpack_require__.n(_node_modules_pnpm_css_loader_7_1_5_rspack_core_2_3_1_webpack_5_112_0_clean_css_5_3_3_cssnano_5_1_15_post_febb2288d7899141871e91de754b8b49_node_modules_css_loader_dist_runtime_api_js__rspack_import_0);
// Imports


var ___CSS_LOADER_EXPORT___ = _node_modules_pnpm_css_loader_7_1_5_rspack_core_2_3_1_webpack_5_112_0_clean_css_5_3_3_cssnano_5_1_15_post_febb2288d7899141871e91de754b8b49_node_modules_css_loader_dist_runtime_api_js__rspack_import_0_default()((_node_modules_pnpm_css_loader_7_1_5_rspack_core_2_3_1_webpack_5_112_0_clean_css_5_3_3_cssnano_5_1_15_post_febb2288d7899141871e91de754b8b49_node_modules_css_loader_dist_runtime_noSourceMaps_js__rspack_import_1_default()));
// Module
___CSS_LOADER_EXPORT___.push([module.id, ".version-information .table[data-v-5411224c]{width:100%;color:#666;border-collapse:collapse;background-color:#fff}.version-information .table td[data-v-5411224c]{position:relative;padding:9px 15px;overflow:hidden;font-size:14px;line-height:20px;text-overflow:ellipsis;white-space:nowrap;border:1px solid #e6e6e6}.version-information .table td[data-v-5411224c]:nth-child(odd){width:20%;text-align:right;background-color:#f7f7f7}", ""]);
// Exports
/* export default */ __webpack_exports__["default"] = (___CSS_LOADER_EXPORT___);


}),
52076: (function (__unused_rspack_module, __webpack_exports__, __webpack_require__) {
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": function() { return /* binding */ VersionInformation; }
});

;// CONCATENATED MODULE: ./node_modules/.pnpm/vue-loader@15.9.8_@vue+compiler-sfc@3.5.44_css-loader@7.1.5_@rspack+core@2.3.1_webpack@_b2cbf52322a1d49b31c7b4debdc3f48e/node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/.pnpm/vue-loader@15.9.8_@vue+compiler-sfc@3.5.44_css-loader@7.1.5_@rspack+core@2.3.1_webpack@_b2cbf52322a1d49b31c7b4debdc3f48e/node_modules/vue-loader/lib/index.js??vue-loader-options!./src/views/index/components/VersionInformation.vue?vue&type=template&id=5411224c&scoped=true&
var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('el-card',{staticClass:"version-information",attrs:{"shadow":"hover"},scopedSlots:_vm._u([{key:"header",fn:function(){return [_c('vab-icon',{attrs:{"icon":"information-line"}})]},proxy:true}])},[_c('el-scrollbar',[_c('table',{staticClass:"table"},[_c('tr',[_c('td',[_vm._v("vue")]),_c('td',[_vm._v(_vm._s(_vm.dependencies['vue']))]),_c('td',[_vm._v("@vue/cli")]),_c('td',[_vm._v(_vm._s(_vm.devDependencies['@vue/cli-service']))])]),_c('tr',[_c('td',[_vm._v("vuex")]),_c('td',[_vm._v(_vm._s(_vm.dependencies['vuex']))]),_c('td',[_vm._v("vue-router")]),_c('td',[_vm._v(_vm._s(_vm.dependencies['vue-router']))])]),_c('tr',[_c('td',[_vm._v("element-ui")]),_c('td',[_vm._v(_vm._s(_vm.dependencies['element-ui']))]),_c('td',[_vm._v("axios")]),_c('td',[_vm._v(_vm._s(_vm.dependencies['axios']))])]),_c('tr',[_c('td',[_vm._v("授权渠道")]),_c('td',{attrs:{"colspan":"3"}},[_c('a',{attrs:{"href":"https://vuejs-core.cn/authorization","target":"_blank"}},[_c('el-button',{staticStyle:{"margin-left":"10px"},attrs:{"type":"primary"}},[_vm._v("PRO付费版本 购买源码 ￥699")])],1),_c('a',{attrs:{"href":"https://vuejs-core.cn/authorization","target":"_blank"}},[_c('el-button',{staticStyle:{"margin-left":"10px"},attrs:{"type":"primary"}},[_vm._v("Plus付费版本 购买源码 ￥799")])],1),_c('a',{attrs:{"href":"https://github.com/zxwk1998/vue-admin-better/","target":"_blank"}},[_c('el-button',{staticStyle:{"margin-left":"10px"},attrs:{"type":"warning"}},[_vm._v("开源免费版")])],1)])])])])],1)}
var staticRenderFns = []


// EXTERNAL MODULE: ./package.json
var package_0 = __webpack_require__(8330);
;// CONCATENATED MODULE: ./node_modules/.pnpm/babel-loader@10.1.1_@babel+core@7.29.7_supports-color@8.1.1__@rspack+core@2.3.1_webpack_df2a69db421704a5dc28c732247d8bf3/node_modules/babel-loader/lib/index.js??clonedRuleSet-1[0].rules[0].use!./node_modules/.pnpm/vue-loader@15.9.8_@vue+compiler-sfc@3.5.44_css-loader@7.1.5_@rspack+core@2.3.1_webpack@_b2cbf52322a1d49b31c7b4debdc3f48e/node_modules/vue-loader/lib/index.js??vue-loader-options!./src/views/index/components/VersionInformation.vue?vue&type=script&lang=js&
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//


/* export default */ var VersionInformationvue_type_script_lang_js_ = ({
  data() {
    return {
      updateTime: "2026-11-8 08:24:59",
      dependencies: package_0.dependencies,
      devDependencies: package_0.devDependencies
    };
  }
});
;// CONCATENATED MODULE: ./src/views/index/components/VersionInformation.vue?vue&type=script&lang=js&
 /* export default */ var components_VersionInformationvue_type_script_lang_js_ = (VersionInformationvue_type_script_lang_js_); 
// EXTERNAL MODULE: ./node_modules/.pnpm/style-loader@4.0.0_webpack@5.112.0_clean-css@5.3.3_cssnano@5.1.15_postcss@8.5.31__csso@_5e4648e6e53b394848c19cc80c3de11a/node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js
var injectStylesIntoStyleTag = __webpack_require__(74274);
var injectStylesIntoStyleTag_default = /*#__PURE__*/__webpack_require__.n(injectStylesIntoStyleTag);
// EXTERNAL MODULE: ./node_modules/.pnpm/style-loader@4.0.0_webpack@5.112.0_clean-css@5.3.3_cssnano@5.1.15_postcss@8.5.31__csso@_5e4648e6e53b394848c19cc80c3de11a/node_modules/style-loader/dist/runtime/styleDomAPI.js
var styleDomAPI = __webpack_require__(91363);
var styleDomAPI_default = /*#__PURE__*/__webpack_require__.n(styleDomAPI);
// EXTERNAL MODULE: ./node_modules/.pnpm/style-loader@4.0.0_webpack@5.112.0_clean-css@5.3.3_cssnano@5.1.15_postcss@8.5.31__csso@_5e4648e6e53b394848c19cc80c3de11a/node_modules/style-loader/dist/runtime/insertBySelector.js
var insertBySelector = __webpack_require__(90353);
var insertBySelector_default = /*#__PURE__*/__webpack_require__.n(insertBySelector);
// EXTERNAL MODULE: ./node_modules/.pnpm/style-loader@4.0.0_webpack@5.112.0_clean-css@5.3.3_cssnano@5.1.15_postcss@8.5.31__csso@_5e4648e6e53b394848c19cc80c3de11a/node_modules/style-loader/dist/runtime/setAttributesWithoutAttributes.js
var setAttributesWithoutAttributes = __webpack_require__(60794);
var setAttributesWithoutAttributes_default = /*#__PURE__*/__webpack_require__.n(setAttributesWithoutAttributes);
// EXTERNAL MODULE: ./node_modules/.pnpm/style-loader@4.0.0_webpack@5.112.0_clean-css@5.3.3_cssnano@5.1.15_postcss@8.5.31__csso@_5e4648e6e53b394848c19cc80c3de11a/node_modules/style-loader/dist/runtime/insertStyleElement.js
var insertStyleElement = __webpack_require__(74310);
var insertStyleElement_default = /*#__PURE__*/__webpack_require__.n(insertStyleElement);
// EXTERNAL MODULE: ./node_modules/.pnpm/style-loader@4.0.0_webpack@5.112.0_clean-css@5.3.3_cssnano@5.1.15_postcss@8.5.31__csso@_5e4648e6e53b394848c19cc80c3de11a/node_modules/style-loader/dist/runtime/styleTagTransform.js
var styleTagTransform = __webpack_require__(89211);
var styleTagTransform_default = /*#__PURE__*/__webpack_require__.n(styleTagTransform);
// EXTERNAL MODULE: ./node_modules/.pnpm/css-loader@7.1.5_@rspack+core@2.3.1_webpack@5.112.0_clean-css@5.3.3_cssnano@5.1.15_post_febb2288d7899141871e91de754b8b49/node_modules/css-loader/dist/cjs.js??clonedRuleSet-3[0].rules[0].use[1]!./node_modules/.pnpm/vue-loader@15.9.8_@vue+compiler-sfc@3.5.44_css-loader@7.1.5_@rspack+core@2.3.1_webpack@_b2cbf52322a1d49b31c7b4debdc3f48e/node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/.pnpm/sass-loader@10.5.2_sass@1.32.13_webpack@5.112.0_clean-css@5.3.3_cssnano@5.1.15_postcss@_1cefcce83fe5cdf20bc5cc3c32a7e699/node_modules/sass-loader/dist/cjs.js??clonedRuleSet-3[0].rules[0].use[2]!./node_modules/.pnpm/vue-loader@15.9.8_@vue+compiler-sfc@3.5.44_css-loader@7.1.5_@rspack+core@2.3.1_webpack@_b2cbf52322a1d49b31c7b4debdc3f48e/node_modules/vue-loader/lib/index.js??vue-loader-options!./src/views/index/components/VersionInformation.vue?vue&type=style&index=0&id=5411224c&lang=scss&scoped=true&
var VersionInformationvue_type_style_index_0_id_5411224c_lang_scss_scoped_true_ = __webpack_require__(4254);
;// CONCATENATED MODULE: ./node_modules/.pnpm/style-loader@4.0.0_webpack@5.112.0_clean-css@5.3.3_cssnano@5.1.15_postcss@8.5.31__csso@_5e4648e6e53b394848c19cc80c3de11a/node_modules/style-loader/dist/cjs.js!./node_modules/.pnpm/css-loader@7.1.5_@rspack+core@2.3.1_webpack@5.112.0_clean-css@5.3.3_cssnano@5.1.15_post_febb2288d7899141871e91de754b8b49/node_modules/css-loader/dist/cjs.js??clonedRuleSet-3[0].rules[0].use[1]!./node_modules/.pnpm/vue-loader@15.9.8_@vue+compiler-sfc@3.5.44_css-loader@7.1.5_@rspack+core@2.3.1_webpack@_b2cbf52322a1d49b31c7b4debdc3f48e/node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/.pnpm/sass-loader@10.5.2_sass@1.32.13_webpack@5.112.0_clean-css@5.3.3_cssnano@5.1.15_postcss@_1cefcce83fe5cdf20bc5cc3c32a7e699/node_modules/sass-loader/dist/cjs.js??clonedRuleSet-3[0].rules[0].use[2]!./node_modules/.pnpm/vue-loader@15.9.8_@vue+compiler-sfc@3.5.44_css-loader@7.1.5_@rspack+core@2.3.1_webpack@_b2cbf52322a1d49b31c7b4debdc3f48e/node_modules/vue-loader/lib/index.js??vue-loader-options!./src/views/index/components/VersionInformation.vue?vue&type=style&index=0&id=5411224c&lang=scss&scoped=true&

      
      
      
      
      
      
      
      
      

var options = {};

options.styleTagTransform = (styleTagTransform_default());
options.setAttributes = (setAttributesWithoutAttributes_default());
options.insert = insertBySelector_default().bind(null, "head");
options.domAPI = (styleDomAPI_default());
options.insertStyleElement = (insertStyleElement_default());

var update = injectStylesIntoStyleTag_default()(VersionInformationvue_type_style_index_0_id_5411224c_lang_scss_scoped_true_["default"], options);




       /* export default */ var components_VersionInformationvue_type_style_index_0_id_5411224c_lang_scss_scoped_true_ = (VersionInformationvue_type_style_index_0_id_5411224c_lang_scss_scoped_true_["default"] && VersionInformationvue_type_style_index_0_id_5411224c_lang_scss_scoped_true_["default"].locals ? VersionInformationvue_type_style_index_0_id_5411224c_lang_scss_scoped_true_["default"].locals : undefined);

;// CONCATENATED MODULE: ./src/views/index/components/VersionInformation.vue?vue&type=style&index=0&id=5411224c&lang=scss&scoped=true&

// EXTERNAL MODULE: ./node_modules/.pnpm/vue-loader@15.9.8_@vue+compiler-sfc@3.5.44_css-loader@7.1.5_@rspack+core@2.3.1_webpack@_b2cbf52322a1d49b31c7b4debdc3f48e/node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__(61808);
;// CONCATENATED MODULE: ./src/views/index/components/VersionInformation.vue



;


/* normalize component */

var component = (0,componentNormalizer["default"])(
  components_VersionInformationvue_type_script_lang_js_,
  render,
  staticRenderFns,
  false,
  null,
  "5411224c",
  null
  
)

/* export default */ var VersionInformation = (component.exports);

}),
8330: (function (module) {
module.exports = /*#__PURE__*/JSON.parse('{"name":"vue-admin-better","version":"3.0.2","author":"zxwk1998","participants":[],"homepage":"https://vuejs-core.cn","scripts":{"serve:rspack":"node --no-deprecation rspack.js serve","build":"node --no-deprecation rspack.js build","print-info":"node -e \\"require(\'./layouts\').donationConsole()\\"","lint":"eslint {src,mock,library}/**/*.{vue,js} --fix","lint:prettier":"prettier {src,mock,library}/**/*.{html,vue,css,sass,scss,js,ts,md} --write","clear":"rimraf node_modules&&npm install  --registry=--registry=https://registry.npmmirror.com","module:update":"pnpm dlx npm-check-updates -u --reject vue-loader,vue-echarts,webpack,eslint-plugin-prettier,@vue/eslint-config-prettier,prettier,layouts,sass-loader,sass,screenfull,eslint,chalk,vue,vue-template-compiler,vue-router,vuex,@vue/cli-plugin-babel,@vue/cli-plugin-eslint,@vue/cli-service,eslint-plugin-vue --registry=https://registry.npmmirror.com&&pnpm i --no-frozen-lockfile","push":"start ./push.sh"},"repository":{"type":"git","url":"git+https://github.com/zxwk1998/vue-admin-better.git"},"gitHooks":{"pre-commit":"lint-staged"},"lint-staged":{"*.{js,jsx,vue}":["eslint --fix","git add"]},"dependencies":{"axios":"^1.21.0","caniuse-lite":"^1.0.30001823","clipboard":"^2.0.11","core-js":"^3.51.0","dayjs":"^1.11.23","echarts":"6.1.0","element-ui":"^2.15.14","jsencrypt":"^3.5.4","layouts":"file:layouts","lodash":"^4.18.1","marked":"^18.1.3","mockjs":"^1.1.0","nprogress":"^0.2.0","qrcode":"^1.5.4","qs":"^6.17.1","screenfull":"^5.2.0","sortablejs":"^1.15.7","vab-icon":"file:vab-icon","vue":"~2.7.14","vue-echarts":"6.7.3","vue-router":"^3.6.5","vuex":"^3.6.2"},"devDependencies":{"@rspack/cli":"^2.3.1","@rspack/core":"^2.3.1","@rspack/dev-server":"^2.2.2","@vue/cli-plugin-babel":"^5.0.8","archiver":"^8.0.0","babel-eslint":"^10.1.0","babel-loader":"^10.1.1","body-parser":"^2.4.0","chalk":"^4.1.2","chokidar":"^6.0.0","css-loader":"^7.1.5","eslint":"^6.8.0","eslint-plugin-prettier":"^3.4.1","eslint-plugin-vue":"^9.1.1","fs-extra":"^11.4.1","html-rspack-plugin":"^6.1.11","lint-staged":"^17.6.0","path-browserify":"^1.0.1","prettier":"^2.8.8","sass":"~1.32.13","sass-loader":"^10.1.1","style-loader":"^4.0.0","stylelint":"^18.0.0","stylelint-config-prettier":"^9.0.5","stylelint-config-recess-order":"^7.10.0","vue-loader":"15.9.8","vue-template-compiler":"~2.7.14"},"keywords":["vue","admin","dashboard","element-ui","vue-admin","element-admin","boilerplate","admin-template","management-system"],"engines":{"node":">=8.9","npm":">= 3.0.0"}}')

}),

}]);