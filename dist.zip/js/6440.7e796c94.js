"use strict";
(self["webpackChunkvue_admin_better"] = self["webpackChunkvue_admin_better"] || []).push([["6440"], {
31464: (function (module, __unused_webpack_exports, __webpack_require__) {
module.exports = __webpack_require__.p + "static/background.a69dce67d9e3dc78.jpg";

}),

}]);