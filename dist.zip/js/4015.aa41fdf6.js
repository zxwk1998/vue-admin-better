/*!
 * vue-admin-better
 * GitHub: https://github.com/zxwk1998/vue-admin-better
 * Gitee: https://gitee.com/chu1204505056/vue-admin-better
 *
 * 版权所有 (c) 2025 vue-admin-better
 * 本项目使用 MIT 许可证
 * 构建时间: 2026-11-8 08:24:59
 */
"use strict";
(self["rspackChunkvue_admin_better"] = self["rspackChunkvue_admin_better"] || []).push([[4015], {
12174: (function (__unused_rspack_module, __webpack_exports__, __webpack_require__) {
__webpack_require__.r(__webpack_exports__);
/* import */ var _utils_request__rspack_import_0 = __webpack_require__(41376);

function getList(data) {
  return (0,_utils_request__rspack_import_0["default"])({
    url: '/goodsList/getList',
    method: 'post',
    data
  });
}
__webpack_require__.d(__webpack_exports__, {
}, {
  getList: getList
});


}),
93703: (function (module, __webpack_exports__, __webpack_require__) {
__webpack_require__.r(__webpack_exports__);
/* import */ var _node_modules_pnpm_css_loader_7_1_5_rspack_core_2_3_1_webpack_5_112_0_clean_css_5_3_3_cssnano_5_1_15_post_febb2288d7899141871e91de754b8b49_node_modules_css_loader_dist_runtime_noSourceMaps_js__rspack_import_1 = __webpack_require__(55489);
/* import */ var _node_modules_pnpm_css_loader_7_1_5_rspack_core_2_3_1_webpack_5_112_0_clean_css_5_3_3_cssnano_5_1_15_post_febb2288d7899141871e91de754b8b49_node_modules_css_loader_dist_runtime_noSourceMaps_js__rspack_import_1_default = /*#__PURE__*/__webpack_require__.n(_node_modules_pnpm_css_loader_7_1_5_rspack_core_2_3_1_webpack_5_112_0_clean_css_5_3_3_cssnano_5_1_15_post_febb2288d7899141871e91de754b8b49_node_modules_css_loader_dist_runtime_noSourceMaps_js__rspack_import_1);
/* import */ var _node_modules_pnpm_css_loader_7_1_5_rspack_core_2_3_1_webpack_5_112_0_clean_css_5_3_3_cssnano_5_1_15_post_febb2288d7899141871e91de754b8b49_node_modules_css_loader_dist_runtime_api_js__rspack_import_0 = __webpack_require__(78122);
/* import */ var _node_modules_pnpm_css_loader_7_1_5_rspack_core_2_3_1_webpack_5_112_0_clean_css_5_3_3_cssnano_5_1_15_post_febb2288d7899141871e91de754b8b49_node_modules_css_loader_dist_runtime_api_js__rspack_import_0_default = /*#__PURE__*/__webpack_require__.n(_node_modules_pnpm_css_loader_7_1_5_rspack_core_2_3_1_webpack_5_112_0_clean_css_5_3_3_cssnano_5_1_15_post_febb2288d7899141871e91de754b8b49_node_modules_css_loader_dist_runtime_api_js__rspack_import_0);
// Imports


var ___CSS_LOADER_EXPORT___ = _node_modules_pnpm_css_loader_7_1_5_rspack_core_2_3_1_webpack_5_112_0_clean_css_5_3_3_cssnano_5_1_15_post_febb2288d7899141871e91de754b8b49_node_modules_css_loader_dist_runtime_api_js__rspack_import_0_default()((_node_modules_pnpm_css_loader_7_1_5_rspack_core_2_3_1_webpack_5_112_0_clean_css_5_3_3_cssnano_5_1_15_post_febb2288d7899141871e91de754b8b49_node_modules_css_loader_dist_runtime_noSourceMaps_js__rspack_import_1_default()));
// Module
___CSS_LOADER_EXPORT___.push([module.id, ".page-header{background:linear-gradient(135deg, #4d8af0 0%, #1a56db 100%);border-radius:12px;padding:30px;margin-bottom:24px;color:#fff;box-shadow:0 8px 32px rgba(102,126,234,.3)}.page-header .header-content{display:flex;justify-content:space-between;align-items:center}.page-header .header-content .header-left .page-title{font-size:2rem;font-weight:700;margin:0 0 8px 0;display:flex;align-items:center;gap:12px}.page-header .header-content .header-left .page-title .vab-icon{font-size:1.8rem}.page-header .header-content .header-left .page-description{font-size:1rem;opacity:.9;margin:0}.page-header .header-content .header-right{display:flex;align-items:center;gap:8px;font-size:1.1rem;font-weight:600}.page-header .header-content .header-right .vab-icon{font-size:1.3rem}", ""]);
// Exports
/* export default */ __webpack_exports__["default"] = (___CSS_LOADER_EXPORT___);


}),
45560: (function (module, __webpack_exports__, __webpack_require__) {
__webpack_require__.r(__webpack_exports__);
/* import */ var _node_modules_pnpm_css_loader_7_1_5_rspack_core_2_3_1_webpack_5_112_0_clean_css_5_3_3_cssnano_5_1_15_post_febb2288d7899141871e91de754b8b49_node_modules_css_loader_dist_runtime_noSourceMaps_js__rspack_import_1 = __webpack_require__(55489);
/* import */ var _node_modules_pnpm_css_loader_7_1_5_rspack_core_2_3_1_webpack_5_112_0_clean_css_5_3_3_cssnano_5_1_15_post_febb2288d7899141871e91de754b8b49_node_modules_css_loader_dist_runtime_noSourceMaps_js__rspack_import_1_default = /*#__PURE__*/__webpack_require__.n(_node_modules_pnpm_css_loader_7_1_5_rspack_core_2_3_1_webpack_5_112_0_clean_css_5_3_3_cssnano_5_1_15_post_febb2288d7899141871e91de754b8b49_node_modules_css_loader_dist_runtime_noSourceMaps_js__rspack_import_1);
/* import */ var _node_modules_pnpm_css_loader_7_1_5_rspack_core_2_3_1_webpack_5_112_0_clean_css_5_3_3_cssnano_5_1_15_post_febb2288d7899141871e91de754b8b49_node_modules_css_loader_dist_runtime_api_js__rspack_import_0 = __webpack_require__(78122);
/* import */ var _node_modules_pnpm_css_loader_7_1_5_rspack_core_2_3_1_webpack_5_112_0_clean_css_5_3_3_cssnano_5_1_15_post_febb2288d7899141871e91de754b8b49_node_modules_css_loader_dist_runtime_api_js__rspack_import_0_default = /*#__PURE__*/__webpack_require__.n(_node_modules_pnpm_css_loader_7_1_5_rspack_core_2_3_1_webpack_5_112_0_clean_css_5_3_3_cssnano_5_1_15_post_febb2288d7899141871e91de754b8b49_node_modules_css_loader_dist_runtime_api_js__rspack_import_0);
// Imports


var ___CSS_LOADER_EXPORT___ = _node_modules_pnpm_css_loader_7_1_5_rspack_core_2_3_1_webpack_5_112_0_clean_css_5_3_3_cssnano_5_1_15_post_febb2288d7899141871e91de754b8b49_node_modules_css_loader_dist_runtime_api_js__rspack_import_0_default()((_node_modules_pnpm_css_loader_7_1_5_rspack_core_2_3_1_webpack_5_112_0_clean_css_5_3_3_cssnano_5_1_15_post_febb2288d7899141871e91de754b8b49_node_modules_css_loader_dist_runtime_noSourceMaps_js__rspack_import_1_default()));
// Module
___CSS_LOADER_EXPORT___.push([module.id, ".goods-list-container .goods-list-card-body[data-v-5a64b9e8]{position:relative;text-align:center;cursor:pointer}.goods-list-container .goods-list-card-body .goods-list-tag-group[data-v-5a64b9e8]{position:absolute;top:10px;right:5px;z-index:9}.goods-list-container .goods-list-card-body .goods-list-image-group[data-v-5a64b9e8]{height:400px;overflow:hidden}.goods-list-container .goods-list-card-body .goods-list-image-group .goods-list-image[data-v-5a64b9e8]{width:100%;height:400px;transition:all ease-in-out .3s}.goods-list-container .goods-list-card-body .goods-list-image-group .goods-list-image[data-v-5a64b9e8]:hover{transform:scale(1.1)}.goods-list-container .goods-list-card-body .goods-list-title[data-v-5a64b9e8]{margin:8px 0;font-size:16px;font-weight:bold}.goods-list-container .goods-list-card-body .goods-list-description[data-v-5a64b9e8]{font-size:14px;color:#808695}.goods-list-container .goods-list-card-body .goods-list-price[data-v-5a64b9e8]{margin:8px 0;font-size:14px;color:#fa8c16}.goods-list-container .goods-list-card-body .goods-list-price s[data-v-5a64b9e8]{color:#c5c8ce}", ""]);
// Exports
/* export default */ __webpack_exports__["default"] = (___CSS_LOADER_EXPORT___);


}),
94040: (function (__unused_rspack_module, __webpack_exports__, __webpack_require__) {
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": function() { return /* binding */ VabPageHeader; }
});

;// CONCATENATED MODULE: ./node_modules/.pnpm/vue-loader@15.9.8_@vue+compiler-sfc@3.5.44_css-loader@7.1.5_@rspack+core@2.3.1_webpack@_b2cbf52322a1d49b31c7b4debdc3f48e/node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/.pnpm/vue-loader@15.9.8_@vue+compiler-sfc@3.5.44_css-loader@7.1.5_@rspack+core@2.3.1_webpack@_b2cbf52322a1d49b31c7b4debdc3f48e/node_modules/vue-loader/lib/index.js??vue-loader-options!./src/components/VabPageHeader/index.vue?vue&type=template&id=2b14fb2d&
var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('div',{staticClass:"page-header",class:_vm.customClass},[_c('div',{staticClass:"header-content"},[_c('div',{staticClass:"header-left"},[_c('h1',{staticClass:"page-title"},[(_vm.icon)?_c('vab-icon',{attrs:{"icon":_vm.icon}}):_vm._e(),_vm._v("\n        "+_vm._s(_vm.title)+"\n      ")],1),(_vm.description)?_c('p',{staticClass:"page-description",domProps:{"innerHTML":_vm._s(_vm.description)}}):_vm._e()]),(_vm.rightIcon || _vm.rightText)?_c('div',{staticClass:"header-right"},[_vm._t("right",function(){return [(_vm.rightIcon)?_c('vab-icon',{attrs:{"icon":_vm.rightIcon}}):_vm._e(),(_vm.rightText)?_c('span',[_vm._v(_vm._s(_vm.rightText))]):_vm._e()]})],2):_vm._e()])])}
var staticRenderFns = []


;// CONCATENATED MODULE: ./node_modules/.pnpm/babel-loader@10.1.1_@babel+core@7.29.7_supports-color@8.1.1__@rspack+core@2.3.1_webpack_df2a69db421704a5dc28c732247d8bf3/node_modules/babel-loader/lib/index.js??clonedRuleSet-1[0].rules[0].use!./node_modules/.pnpm/vue-loader@15.9.8_@vue+compiler-sfc@3.5.44_css-loader@7.1.5_@rspack+core@2.3.1_webpack@_b2cbf52322a1d49b31c7b4debdc3f48e/node_modules/vue-loader/lib/index.js??vue-loader-options!./src/components/VabPageHeader/index.vue?vue&type=script&lang=js&
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

/* export default */ var VabPageHeadervue_type_script_lang_js_ = ({
  name: 'VabPageHeader',
  props: {
    title: {
      type: String,
      required: true
    },
    description: {
      type: String,
      default: ''
    },
    icon: {
      type: Array,
      default: () => []
    },
    rightIcon: {
      type: Array,
      default: () => []
    },
    rightText: {
      type: String,
      default: ''
    },
    customClass: {
      type: String,
      default: ''
    }
  }
});
;// CONCATENATED MODULE: ./src/components/VabPageHeader/index.vue?vue&type=script&lang=js&
 /* export default */ var components_VabPageHeadervue_type_script_lang_js_ = (VabPageHeadervue_type_script_lang_js_); 
// EXTERNAL MODULE: ./node_modules/.pnpm/style-loader@4.0.0_webpack@5.112.0_clean-css@5.3.3_cssnano@5.1.15_postcss@8.5.31__csso@_5e4648e6e53b394848c19cc80c3de11a/node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js
var injectStylesIntoStyleTag = __webpack_require__(74274);
var injectStylesIntoStyleTag_default = /*#__PURE__*/__webpack_require__.n(injectStylesIntoStyleTag);
// EXTERNAL MODULE: ./node_modules/.pnpm/style-loader@4.0.0_webpack@5.112.0_clean-css@5.3.3_cssnano@5.1.15_postcss@8.5.31__csso@_5e4648e6e53b394848c19cc80c3de11a/node_modules/style-loader/dist/runtime/styleDomAPI.js
var styleDomAPI = __webpack_require__(91363);
var styleDomAPI_default = /*#__PURE__*/__webpack_require__.n(styleDomAPI);
// EXTERNAL MODULE: ./node_modules/.pnpm/style-loader@4.0.0_webpack@5.112.0_clean-css@5.3.3_cssnano@5.1.15_postcss@8.5.31__csso@_5e4648e6e53b394848c19cc80c3de11a/node_modules/style-loader/dist/runtime/insertBySelector.js
var insertBySelector = __webpack_require__(90353);
var insertBySelector_default = /*#__PURE__*/__webpack_require__.n(insertBySelector);
// EXTERNAL MODULE: ./node_modules/.pnpm/style-loader@4.0.0_webpack@5.112.0_clean-css@5.3.3_cssnano@5.1.15_postcss@8.5.31__csso@_5e4648e6e53b394848c19cc80c3de11a/node_modules/style-loader/dist/runtime/setAttributesWithoutAttributes.js
var setAttributesWithoutAttributes = __webpack_require__(60794);
var setAttributesWithoutAttributes_default = /*#__PURE__*/__webpack_require__.n(setAttributesWithoutAttributes);
// EXTERNAL MODULE: ./node_modules/.pnpm/style-loader@4.0.0_webpack@5.112.0_clean-css@5.3.3_cssnano@5.1.15_postcss@8.5.31__csso@_5e4648e6e53b394848c19cc80c3de11a/node_modules/style-loader/dist/runtime/insertStyleElement.js
var insertStyleElement = __webpack_require__(74310);
var insertStyleElement_default = /*#__PURE__*/__webpack_require__.n(insertStyleElement);
// EXTERNAL MODULE: ./node_modules/.pnpm/style-loader@4.0.0_webpack@5.112.0_clean-css@5.3.3_cssnano@5.1.15_postcss@8.5.31__csso@_5e4648e6e53b394848c19cc80c3de11a/node_modules/style-loader/dist/runtime/styleTagTransform.js
var styleTagTransform = __webpack_require__(89211);
var styleTagTransform_default = /*#__PURE__*/__webpack_require__.n(styleTagTransform);
// EXTERNAL MODULE: ./node_modules/.pnpm/css-loader@7.1.5_@rspack+core@2.3.1_webpack@5.112.0_clean-css@5.3.3_cssnano@5.1.15_post_febb2288d7899141871e91de754b8b49/node_modules/css-loader/dist/cjs.js??clonedRuleSet-3[0].rules[0].use[1]!./node_modules/.pnpm/vue-loader@15.9.8_@vue+compiler-sfc@3.5.44_css-loader@7.1.5_@rspack+core@2.3.1_webpack@_b2cbf52322a1d49b31c7b4debdc3f48e/node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/.pnpm/sass-loader@10.5.2_sass@1.32.13_webpack@5.112.0_clean-css@5.3.3_cssnano@5.1.15_postcss@_1cefcce83fe5cdf20bc5cc3c32a7e699/node_modules/sass-loader/dist/cjs.js??clonedRuleSet-3[0].rules[0].use[2]!./node_modules/.pnpm/vue-loader@15.9.8_@vue+compiler-sfc@3.5.44_css-loader@7.1.5_@rspack+core@2.3.1_webpack@_b2cbf52322a1d49b31c7b4debdc3f48e/node_modules/vue-loader/lib/index.js??vue-loader-options!./src/components/VabPageHeader/index.vue?vue&type=style&index=0&lang=scss&
var VabPageHeadervue_type_style_index_0_lang_scss_ = __webpack_require__(93703);
;// CONCATENATED MODULE: ./node_modules/.pnpm/style-loader@4.0.0_webpack@5.112.0_clean-css@5.3.3_cssnano@5.1.15_postcss@8.5.31__csso@_5e4648e6e53b394848c19cc80c3de11a/node_modules/style-loader/dist/cjs.js!./node_modules/.pnpm/css-loader@7.1.5_@rspack+core@2.3.1_webpack@5.112.0_clean-css@5.3.3_cssnano@5.1.15_post_febb2288d7899141871e91de754b8b49/node_modules/css-loader/dist/cjs.js??clonedRuleSet-3[0].rules[0].use[1]!./node_modules/.pnpm/vue-loader@15.9.8_@vue+compiler-sfc@3.5.44_css-loader@7.1.5_@rspack+core@2.3.1_webpack@_b2cbf52322a1d49b31c7b4debdc3f48e/node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/.pnpm/sass-loader@10.5.2_sass@1.32.13_webpack@5.112.0_clean-css@5.3.3_cssnano@5.1.15_postcss@_1cefcce83fe5cdf20bc5cc3c32a7e699/node_modules/sass-loader/dist/cjs.js??clonedRuleSet-3[0].rules[0].use[2]!./node_modules/.pnpm/vue-loader@15.9.8_@vue+compiler-sfc@3.5.44_css-loader@7.1.5_@rspack+core@2.3.1_webpack@_b2cbf52322a1d49b31c7b4debdc3f48e/node_modules/vue-loader/lib/index.js??vue-loader-options!./src/components/VabPageHeader/index.vue?vue&type=style&index=0&lang=scss&

      
      
      
      
      
      
      
      
      

var options = {};

options.styleTagTransform = (styleTagTransform_default());
options.setAttributes = (setAttributesWithoutAttributes_default());
options.insert = insertBySelector_default().bind(null, "head");
options.domAPI = (styleDomAPI_default());
options.insertStyleElement = (insertStyleElement_default());

var update = injectStylesIntoStyleTag_default()(VabPageHeadervue_type_style_index_0_lang_scss_["default"], options);




       /* export default */ var components_VabPageHeadervue_type_style_index_0_lang_scss_ = (VabPageHeadervue_type_style_index_0_lang_scss_["default"] && VabPageHeadervue_type_style_index_0_lang_scss_["default"].locals ? VabPageHeadervue_type_style_index_0_lang_scss_["default"].locals : undefined);

;// CONCATENATED MODULE: ./src/components/VabPageHeader/index.vue?vue&type=style&index=0&lang=scss&

// EXTERNAL MODULE: ./node_modules/.pnpm/vue-loader@15.9.8_@vue+compiler-sfc@3.5.44_css-loader@7.1.5_@rspack+core@2.3.1_webpack@_b2cbf52322a1d49b31c7b4debdc3f48e/node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__(61808);
;// CONCATENATED MODULE: ./src/components/VabPageHeader/index.vue



;


/* normalize component */

var component = (0,componentNormalizer["default"])(
  components_VabPageHeadervue_type_script_lang_js_,
  render,
  staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* export default */ var VabPageHeader = (component.exports);

}),
36082: (function (__unused_rspack_module, __webpack_exports__, __webpack_require__) {
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": function() { return /* binding */ mall_goodsList; }
});

;// CONCATENATED MODULE: ./node_modules/.pnpm/vue-loader@15.9.8_@vue+compiler-sfc@3.5.44_css-loader@7.1.5_@rspack+core@2.3.1_webpack@_b2cbf52322a1d49b31c7b4debdc3f48e/node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/.pnpm/vue-loader@15.9.8_@vue+compiler-sfc@3.5.44_css-loader@7.1.5_@rspack+core@2.3.1_webpack@_b2cbf52322a1d49b31c7b4debdc3f48e/node_modules/vue-loader/lib/index.js??vue-loader-options!./src/views/mall/goodsList/index.vue?vue&type=template&id=5a64b9e8&scoped=true&
var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('div',{staticClass:"goods-list-container"},[_c('vab-page-header',{attrs:{"description":"商品展示页面，支持搜索、分页等功能","icon":['fas', 'shopping-bag'],"title":"商品列表"}}),_c('vab-query-form',[_c('vab-query-form-right-panel',{attrs:{"span":24}},[_c('el-form',{ref:"form",attrs:{"inline":true,"model":_vm.queryForm},nativeOn:{"submit":function($event){$event.preventDefault();}}},[_c('el-form-item',[_c('el-input',{attrs:{"placeholder":"商品名称"},model:{value:(_vm.queryForm.title),callback:function ($$v) {_vm.$set(_vm.queryForm, "title", $$v)},expression:"queryForm.title"}})],1),_c('el-form-item',[_c('el-button',{attrs:{"icon":"el-icon-search","native-type":"submit","type":"primary"},on:{"click":_vm.handleQuery}},[_vm._v("查询")])],1)],1)],1)],1),_c('el-row',{attrs:{"gutter":20}},_vm._l((_vm.list),function(item,index){return _c('el-col',{key:index,attrs:{"lg":8,"md":8,"sm":8,"xl":6,"xs":24}},[_c('el-card',{attrs:{"body-style":{ padding: '0px' },"shadow":"hover"}},[_c('div',{staticClass:"goods-list-card-body"},[_c('div',{staticClass:"goods-list-tag-group"},[(item.isRecommend)?_c('el-tag',{attrs:{"hit":"","type":"success"}},[_vm._v("推荐")]):_vm._e(),(item.status === 0)?_c('el-tag',{attrs:{"hit":"","type":"danger"}},[_vm._v("缺货")]):_vm._e()],1),_c('div',{staticClass:"goods-list-image-group"},[_c('img',{staticClass:"goods-list-image",attrs:{"src":item.image}})]),_c('div',{staticClass:"goods-list-title"},[_vm._v("\n            "+_vm._s(item.title)+"\n          ")]),_c('div',{staticClass:"goods-list-description"},[_vm._v("\n            "+_vm._s(item.description)+"\n          ")]),_c('div',{staticClass:"goods-list-price"},[_c('span',[_vm._v("¥ "+_vm._s(item.price)+" 元")])])])])],1)}),1),_c('el-pagination',{attrs:{"background":"","current-page":_vm.queryForm.pageNo,"layout":_vm.layout,"page-size":_vm.queryForm.pageSize,"total":_vm.total},on:{"current-change":_vm.handleCurrentChange,"size-change":_vm.handleSizeChange}})],1)}
var staticRenderFns = []


// EXTERNAL MODULE: ./src/api/goodsList.js
var goodsList = __webpack_require__(12174);
// EXTERNAL MODULE: ./src/components/VabPageHeader/index.vue + 5 modules
var VabPageHeader = __webpack_require__(94040);
;// CONCATENATED MODULE: ./node_modules/.pnpm/babel-loader@10.1.1_@babel+core@7.29.7_supports-color@8.1.1__@rspack+core@2.3.1_webpack_df2a69db421704a5dc28c732247d8bf3/node_modules/babel-loader/lib/index.js??clonedRuleSet-1[0].rules[0].use!./node_modules/.pnpm/vue-loader@15.9.8_@vue+compiler-sfc@3.5.44_css-loader@7.1.5_@rspack+core@2.3.1_webpack@_b2cbf52322a1d49b31c7b4debdc3f48e/node_modules/vue-loader/lib/index.js??vue-loader-options!./src/views/mall/goodsList/index.vue?vue&type=script&lang=js&
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//



/* export default */ var goodsListvue_type_script_lang_js_ = ({
  name: 'Goods',
  components: {
    VabPageHeader: VabPageHeader["default"]
  },
  data() {
    return {
      queryForm: {
        pageNo: 1,
        pageSize: 20,
        title: ''
      },
      list: null,
      listLoading: true,
      layout: 'total, sizes, prev, pager, next, jumper',
      total: 0,
      elementLoadingText: '正在加载...'
    };
  },
  created() {
    this.fetchData();
  },
  methods: {
    handleSizeChange(val) {
      this.queryForm.pageSize = val;
      this.fetchData();
    },
    handleCurrentChange(val) {
      this.queryForm.pageNo = val;
      this.fetchData();
    },
    handleQuery() {
      this.queryForm.pageNo = 1;
      this.fetchData();
    },
    async fetchData() {
      this.listLoading = true;
      const {
        data,
        totalCount
      } = await (0,goodsList.getList)(this.queryForm);
      this.list = data;
      this.total = totalCount;
    }
  }
});
;// CONCATENATED MODULE: ./src/views/mall/goodsList/index.vue?vue&type=script&lang=js&
 /* export default */ var mall_goodsListvue_type_script_lang_js_ = (goodsListvue_type_script_lang_js_); 
// EXTERNAL MODULE: ./node_modules/.pnpm/style-loader@4.0.0_webpack@5.112.0_clean-css@5.3.3_cssnano@5.1.15_postcss@8.5.31__csso@_5e4648e6e53b394848c19cc80c3de11a/node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js
var injectStylesIntoStyleTag = __webpack_require__(74274);
var injectStylesIntoStyleTag_default = /*#__PURE__*/__webpack_require__.n(injectStylesIntoStyleTag);
// EXTERNAL MODULE: ./node_modules/.pnpm/style-loader@4.0.0_webpack@5.112.0_clean-css@5.3.3_cssnano@5.1.15_postcss@8.5.31__csso@_5e4648e6e53b394848c19cc80c3de11a/node_modules/style-loader/dist/runtime/styleDomAPI.js
var styleDomAPI = __webpack_require__(91363);
var styleDomAPI_default = /*#__PURE__*/__webpack_require__.n(styleDomAPI);
// EXTERNAL MODULE: ./node_modules/.pnpm/style-loader@4.0.0_webpack@5.112.0_clean-css@5.3.3_cssnano@5.1.15_postcss@8.5.31__csso@_5e4648e6e53b394848c19cc80c3de11a/node_modules/style-loader/dist/runtime/insertBySelector.js
var insertBySelector = __webpack_require__(90353);
var insertBySelector_default = /*#__PURE__*/__webpack_require__.n(insertBySelector);
// EXTERNAL MODULE: ./node_modules/.pnpm/style-loader@4.0.0_webpack@5.112.0_clean-css@5.3.3_cssnano@5.1.15_postcss@8.5.31__csso@_5e4648e6e53b394848c19cc80c3de11a/node_modules/style-loader/dist/runtime/setAttributesWithoutAttributes.js
var setAttributesWithoutAttributes = __webpack_require__(60794);
var setAttributesWithoutAttributes_default = /*#__PURE__*/__webpack_require__.n(setAttributesWithoutAttributes);
// EXTERNAL MODULE: ./node_modules/.pnpm/style-loader@4.0.0_webpack@5.112.0_clean-css@5.3.3_cssnano@5.1.15_postcss@8.5.31__csso@_5e4648e6e53b394848c19cc80c3de11a/node_modules/style-loader/dist/runtime/insertStyleElement.js
var insertStyleElement = __webpack_require__(74310);
var insertStyleElement_default = /*#__PURE__*/__webpack_require__.n(insertStyleElement);
// EXTERNAL MODULE: ./node_modules/.pnpm/style-loader@4.0.0_webpack@5.112.0_clean-css@5.3.3_cssnano@5.1.15_postcss@8.5.31__csso@_5e4648e6e53b394848c19cc80c3de11a/node_modules/style-loader/dist/runtime/styleTagTransform.js
var styleTagTransform = __webpack_require__(89211);
var styleTagTransform_default = /*#__PURE__*/__webpack_require__.n(styleTagTransform);
// EXTERNAL MODULE: ./node_modules/.pnpm/css-loader@7.1.5_@rspack+core@2.3.1_webpack@5.112.0_clean-css@5.3.3_cssnano@5.1.15_post_febb2288d7899141871e91de754b8b49/node_modules/css-loader/dist/cjs.js??clonedRuleSet-3[0].rules[0].use[1]!./node_modules/.pnpm/vue-loader@15.9.8_@vue+compiler-sfc@3.5.44_css-loader@7.1.5_@rspack+core@2.3.1_webpack@_b2cbf52322a1d49b31c7b4debdc3f48e/node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/.pnpm/sass-loader@10.5.2_sass@1.32.13_webpack@5.112.0_clean-css@5.3.3_cssnano@5.1.15_postcss@_1cefcce83fe5cdf20bc5cc3c32a7e699/node_modules/sass-loader/dist/cjs.js??clonedRuleSet-3[0].rules[0].use[2]!./node_modules/.pnpm/vue-loader@15.9.8_@vue+compiler-sfc@3.5.44_css-loader@7.1.5_@rspack+core@2.3.1_webpack@_b2cbf52322a1d49b31c7b4debdc3f48e/node_modules/vue-loader/lib/index.js??vue-loader-options!./src/views/mall/goodsList/index.vue?vue&type=style&index=0&id=5a64b9e8&lang=scss&scoped=true&
var goodsListvue_type_style_index_0_id_5a64b9e8_lang_scss_scoped_true_ = __webpack_require__(45560);
;// CONCATENATED MODULE: ./node_modules/.pnpm/style-loader@4.0.0_webpack@5.112.0_clean-css@5.3.3_cssnano@5.1.15_postcss@8.5.31__csso@_5e4648e6e53b394848c19cc80c3de11a/node_modules/style-loader/dist/cjs.js!./node_modules/.pnpm/css-loader@7.1.5_@rspack+core@2.3.1_webpack@5.112.0_clean-css@5.3.3_cssnano@5.1.15_post_febb2288d7899141871e91de754b8b49/node_modules/css-loader/dist/cjs.js??clonedRuleSet-3[0].rules[0].use[1]!./node_modules/.pnpm/vue-loader@15.9.8_@vue+compiler-sfc@3.5.44_css-loader@7.1.5_@rspack+core@2.3.1_webpack@_b2cbf52322a1d49b31c7b4debdc3f48e/node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/.pnpm/sass-loader@10.5.2_sass@1.32.13_webpack@5.112.0_clean-css@5.3.3_cssnano@5.1.15_postcss@_1cefcce83fe5cdf20bc5cc3c32a7e699/node_modules/sass-loader/dist/cjs.js??clonedRuleSet-3[0].rules[0].use[2]!./node_modules/.pnpm/vue-loader@15.9.8_@vue+compiler-sfc@3.5.44_css-loader@7.1.5_@rspack+core@2.3.1_webpack@_b2cbf52322a1d49b31c7b4debdc3f48e/node_modules/vue-loader/lib/index.js??vue-loader-options!./src/views/mall/goodsList/index.vue?vue&type=style&index=0&id=5a64b9e8&lang=scss&scoped=true&

      
      
      
      
      
      
      
      
      

var options = {};

options.styleTagTransform = (styleTagTransform_default());
options.setAttributes = (setAttributesWithoutAttributes_default());
options.insert = insertBySelector_default().bind(null, "head");
options.domAPI = (styleDomAPI_default());
options.insertStyleElement = (insertStyleElement_default());

var update = injectStylesIntoStyleTag_default()(goodsListvue_type_style_index_0_id_5a64b9e8_lang_scss_scoped_true_["default"], options);




       /* export default */ var mall_goodsListvue_type_style_index_0_id_5a64b9e8_lang_scss_scoped_true_ = (goodsListvue_type_style_index_0_id_5a64b9e8_lang_scss_scoped_true_["default"] && goodsListvue_type_style_index_0_id_5a64b9e8_lang_scss_scoped_true_["default"].locals ? goodsListvue_type_style_index_0_id_5a64b9e8_lang_scss_scoped_true_["default"].locals : undefined);

;// CONCATENATED MODULE: ./src/views/mall/goodsList/index.vue?vue&type=style&index=0&id=5a64b9e8&lang=scss&scoped=true&

// EXTERNAL MODULE: ./node_modules/.pnpm/vue-loader@15.9.8_@vue+compiler-sfc@3.5.44_css-loader@7.1.5_@rspack+core@2.3.1_webpack@_b2cbf52322a1d49b31c7b4debdc3f48e/node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__(61808);
;// CONCATENATED MODULE: ./src/views/mall/goodsList/index.vue



;


/* normalize component */

var component = (0,componentNormalizer["default"])(
  mall_goodsListvue_type_script_lang_js_,
  render,
  staticRenderFns,
  false,
  null,
  "5a64b9e8",
  null
  
)

/* export default */ var mall_goodsList = (component.exports);

}),

}]);